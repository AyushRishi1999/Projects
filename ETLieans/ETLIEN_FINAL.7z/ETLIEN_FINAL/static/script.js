
let mediaRecorder;
let audioChunks = [];
let placeholderNumber = document.getElementById("placeholderNumber");
let waitingText = document.querySelector('.waiting-text');

function showLoading() {
// Show both primary and secondary loading dots
document.querySelector('.loading-dots').style.display = 'flex';
document.querySelector('.loading-dots1').style.display = 'flex';
document.getElementById('aiOutputPlaceholder').textContent = "Generating feedback...";
}   

function hidePrimaryLoading() {
    // Hide primary loading dots when the first task is done
    document.querySelector('.loading-dots').style.display = 'none';
}

function hideSecondaryLoading() {
    // Hide secondary loading dots when the second task is done
    document.querySelector('.loading-dots1').style.display = 'none';
}
function updateCSATScore(csat_score) {
    const placeholderNumber = document.getElementById("placeholderNumber");
    const waitingText = document.querySelector('.waiting-text');

    if (csat_score > 0) {
        placeholderNumber.innerText = csat_score.toFixed(1);

        // Apply color based on score range
        if (csat_score >= 8) {
            placeholderNumber.style.color = "green"; // High score
        } else if (csat_score >= 5) {
            placeholderNumber.style.color = "orange"; // Mid score
        } else {
            placeholderNumber.style.color = "red"; // Low score
        }

        waitingText.style.display = 'none'; // Hide waiting text
    } else {
        placeholderNumber.innerText = "0.0";
        placeholderNumber.style.color = "gray"; // Neutral color
        waitingText.style.display = 'block'; // Show waiting text
    }
    hidePrimaryLoading();
}

// This function updates the emotion metrics on the page
function updateEmotionMetrics(metrics) {
    const emotions = ['anger', 'happiness', 'disgust', 'sadness', 'fear'];
    emotions.forEach(emotion => {
        const elementId = `emotion_ai_output_${emotion}`;  // The ID of the HTML element for the emotion
        const element = document.getElementById(elementId);

        // Check if the element exists and if the emotion exists in metrics
        if (element && metrics[emotion] !== undefined) {
            element.innerText = `${metrics[emotion]}`;  // Update the text content with the score
        } else {
            console.error(`Missing metric for ${emotion}`);  // Log if missing
        }
    });
    hideSecondaryLoading();
}

// Call this function after the emotion metrics are fetched
async function fetchEmotionMetrics() {
    try {
        // Make the API request to fetch the emotion metrics
        const response = await fetch('/secondaryModel_output', { method: 'POST' });
        const result = await response.json();  // Assuming the result is an object with emotions as keys and scores as values

        // Call updateEmotionMetrics to update the UI
        updateEmotionMetrics(result);
    } catch (error) {
        console.error("Error fetching emotion metrics:", error);
    }

}

document.addEventListener('DOMContentLoaded', function() {
    placeholderNumber.innerText = "0.0";  // Default to 0.0
    placeholderNumber.style.color = "gray";  // Default to gray color
    waitingText.style.display = 'block';  // Show waiting text by default

    const recordButton = document.getElementById('recordButton');

    // File upload form handler
    document.getElementById('uploadForm').onsubmit = async function(event) {
        event.preventDefault();
        showLoading(); // Show loading dots

        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = 'audio/*';

        fileInput.onchange = async function(event) {
            const file = event.target.files[0];
            if (file) {
                const formData = new FormData();
                formData.append('audio', file);

                try {
                    // First API Call to /upload
                    const response = await fetch('/primaryModel_output', {
                        method: 'POST',
                        body: formData
                    });
                    const result = await response.json();

                    if (result.model_feedback_text) {
                        document.getElementById('aiOutputPlaceholder').innerText = result.model_feedback_text;
                    } else {
                        console.error(result.error);
                    }

                    let csat_score = result.csat_score || 0.0;
                    updateCSATScore(csat_score);
                    // Second API Call to /secondaryModel_output
                    const response2 = await fetch('/secondaryModel_output', {
                        method: 'POST',
                        body: formData
                    });

                    const result2 = await response2.json();
                    
                    // Update Emotion Metrics
                    updateEmotionMetrics(result2);
                    console.log(result2)
                } catch (error) {
                    console.error("Error uploading file:", error);
                } 
            }
        };

        fileInput.click(); // Trigger the file selection dialog
    };
   
    // Audio recording handler
    recordButton.addEventListener('click', async function() {
        if (!mediaRecorder) {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaRecorder = new MediaRecorder(stream);

            mediaRecorder.ondataavailable = function(event) {
                audioChunks.push(event.data);
            };

            mediaRecorder.onstop = async function() {
                showLoading(); // Show loading dots during upload

                const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
                const formData = new FormData();
                formData.append('audio', audioBlob);

                try {
                    const response = await fetch('/primaryModel_output', {
                        method: 'POST',
                        body: formData
                    });
                    const result = await response.json();

                    if (result.model_feedback_text) {
                        document.getElementById('aiOutputPlaceholder').innerText = result.model_feedback_text;
                    } else {
                        console.error(result.error);
                    }

                    let csat_score = result.csat_score || 0.0;
                    updateCSATScore(csat_score);

                    const response2 = await fetch('/secondaryModel_output', {
                        method: 'POST',
                        body: formData
                    });
                    const result2 = await response2.json();
                    
                    // Update Emotion Metrics
                    updateEmotionMetrics(result2);
                    console.log(result2);
                } catch (error) {
                    console.error("Error during recording upload:", error);
                } finally {

                    audioChunks = [];
                }
            };
        }

        if (mediaRecorder.state === 'inactive') {
            mediaRecorder.start();
            recordButton.textContent = 'Stop Recording';
        } else {
            mediaRecorder.stop();
            recordButton.textContent = 'Record';
        }
    });
});

setTimeout(function() {
    var flashMessages = document.querySelectorAll('.flash-message');
    flashMessages.forEach(function(message) {
        message.style.opacity = 0;  // Fade out the message
        setTimeout(function() {
            message.style.display = 'none';  // Remove the message from view
        }, 1000);  // Wait for the fade-out transition before hiding the message
    });
}, 5000); 
/*Log out*/
document.addEventListener('DOMContentLoaded', () => {
const loginForm = document.getElementById('loginForm');
const logoutForm = document.getElementById('logoutForm');

// Check login state from sessionStorage
const isLoggedIn = Boolean(sessionStorage.getItem('loggedIn'));

if (isLoggedIn) {
    loginForm.style.display = 'none';
    logoutForm.style.display = 'block';
} else {
    loginForm.style.display = 'block';
    logoutForm.style.display = 'none';
}

// Handle login simulation
loginForm?.addEventListener('submit', () => {
    sessionStorage.setItem('loggedIn', true);
});

// Handle logout simulation
logoutForm?.addEventListener('submit', () => {
    sessionStorage.removeItem('loggedIn');
});
});
