
from transformers import AutoTokenizer,AutoModelForSeq2SeqLM
from flask import Flask, Response, request, jsonify, render_template, redirect,session,flash, redirect, url_for
from flask_cors import CORS
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt

import requests
import os
import speech_recognition as sr
import torch 
import torch.nn.functional as F
import torchaudio
from pydub import AudioSegment
from transformers import AutoTokenizer, RobertaForSequenceClassification,AutoModelForSeq2SeqLM,RobertaTokenizer,AutoConfig, Wav2Vec2FeatureExtractor, Wav2Vec2ForSequenceClassification
import IPython.display as ipd
import numpy as np

#DB
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from datetime import datetime
from sqlalchemy.exc import IntegrityError
import boto3

import re
import nltk

from nltk.tokenize import RegexpTokenizer
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.corpus import wordnet
from nltk.stem import WordNetLemmatizer




#UPDATE VARS
# Configure S3
S3_BUCKET = 'etliens1'
S3_REGION = 'us-east-1'  # e.g., 'us-east-1'

s3_client = boto3.client('s3', region_name=S3_REGION)
s3_url_index = 'https://etliens1.s3.us-east-1.amazonaws.com/index.html'
S3_lOGIN_PAGE ='https://etliens1.s3.us-east-1.amazonaws.com/login.html'
S3_register_PAGE ='https://etliens1.s3.us-east-1.amazonaws.com/register.html'


'''
$env:AWS_DB_USER="admin"
$env:AWS_DB_PASSWORD="AWSRobby123"
$env:AWS_DB_HOST="etliens.cstkr2o37wwi.us-east-1.rds.amazonaws.com"
$env:AWS_DB_NAME="etliens"
'''


#===================-------------App Creation and Routing-------------===================#


app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 75 * 1024 * 1024  # 75 MB


app.config['SQLALCHEMY_DATABASE_URI'] = f"mysql+pymysql://{os.getenv('AWS_DB_USER')}:{os.getenv('AWS_DB_PASSWORD')}@{os.getenv('AWS_DB_HOST')}/{os.getenv('AWS_DB_NAME')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.urandom(24) 
app.config['SQLALCHEMY_POOL_RECYCLE'] = 300
CORS(app)
#===================-------------Declare Models-------------===================#
# Load the tokenizer and model
repo_id_eval = "rconnor1890/flan_t5_chatbot_evaluation_model"
tokenizer = AutoTokenizer.from_pretrained(repo_id_eval, add_prefix_space=True)
eval_model = AutoModelForSeq2SeqLM.from_pretrained(repo_id_eval)

csat_id = "rconnor1890/csat_score_prediction_bert"
csat_model = RobertaForSequenceClassification.from_pretrained(csat_id)
tokenizer_csat = RobertaTokenizer.from_pretrained(csat_id) 

# Check for GPU
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
emotion_model_name = "harshit345/xlsr-wav2vec-speech-emotion-recognition"
# Load config and feature extractor
config = AutoConfig.from_pretrained(emotion_model_name)
config.gradient_checkpointing = False
feature_extractor = Wav2Vec2FeatureExtractor.from_pretrained(emotion_model_name)
# Get sampling rate from feature extractor
sampling_rate = feature_extractor.sampling_rate
# Load the model for sequence classification
emotion_model = Wav2Vec2ForSequenceClassification.from_pretrained(emotion_model_name).to(device)


# Ensure the uploads directory exists
os.makedirs('uploads', exist_ok=True)



#===================-------------Support Functions-------------===================#

#File Handling
def save_file_path(request):
    """
    Handle file upload, save it to the server, convert to WAV if needed, and return the saved file path.
    """
    try:
        # Check if the audio file is in the request
        if 'audio' not in request.files:
            raise ValueError("No audio file uploaded.")

        file = request.files['audio']

        # Ensure uploads directory exists
        os.makedirs('uploads', exist_ok=True)

        # Secure the filename and determine the save path
        file_path = os.path.join('uploads', secure_filename(file.filename))

        # Save the uploaded file
        file.save(file_path)

        # Convert to WAV if the file is not already in WAV format
        if not file_path.endswith('.wav'):
            wav_path = convert_to_wav(file_path)
            if wav_path != file_path:  # Only remove original if conversion happened
                os.remove(file_path)
                file_path = wav_path

        print(f"File uploaded and saved at: {file_path}")

        return file_path

    except ValueError as e:
        return jsonify({'error': str(e)}), 400


def convert_to_wav(file_path):
    """
    Convert an audio file to WAV format and return the new file path.
    """
    audio = AudioSegment.from_file(file_path)
    wav_path = file_path.rsplit('.', 1)[0] + '.wav'  # Replace the original extension with .wav
    audio.export(wav_path, format='wav')
    return wav_path

#Modeling Support
def scale_score_to_1_10(score):
    return 1 + 4.5 * (score + 1)

def transcribe_audio(file_path):
    """Transcribe audio to text."""
    r = sr.Recognizer()
    try:
        with sr.AudioFile(file_path) as source:
            audio_data = r.record(source)
            return r.recognize_google(audio_data)
    except sr.UnknownValueError:
        print("Google Speech Recognition could not understand audio")
    except sr.RequestError as e:
        print(f"Could not request results from Google Speech Recognition service; {e}")
    except Exception as e:
        print("Error processing audio file: ", e)
    return None
#----Emotions Model Support
def speech_file_to_array_fn(path, sampling_rate):
    speech_array, _sampling_rate = torchaudio.load(path)
    resampler = torchaudio.transforms.Resample(_sampling_rate)
    speech = resampler(speech_array).squeeze().numpy()
    return speech

# Prediction function
def predict(path, sampling_rate):
    speech = speech_file_to_array_fn(path, sampling_rate)
    
    # Extract features from speech
    inputs = feature_extractor(speech, sampling_rate=sampling_rate, return_tensors="pt", padding=True)
    
    # Move input tensors to the correct device (GPU or CPU)
    inputs = {key: inputs[key].to(device) for key in inputs}
    
    # Perform inference
    with torch.no_grad():
        logits = emotion_model(**inputs).logits
    
    # Apply softmax to get class probabilities
    scores = F.softmax(logits, dim=1).detach().cpu().numpy()[0]
    
    # Format the results
    outputs = [{"Emotion": config.id2label[i], "Score": f"{round(score * 100, 3):.1f}%"} for i, score in enumerate(scores)]
    return outputs


#Preprocessing for Conversation Detail

def remove_html(text):
    text = re.sub(r'<[^>]+>', ' ', text)
    text = re.sub(r'([^\s\w_])+', ' ', text)
    text = re.sub(r'[\n\r]', ' ', text)
    text = re.sub(r'\d+', ' ', text)
    return text
def tokenizer_explodes(text):  
    text = text.lower()
    review = re.sub('[^a-zA-Z0-9]', ' ', text)  
    tokenizer_explode= RegexpTokenizer(r'\w+|\$[\d\.]+|\S+')
    words = tokenizer_explode.tokenize(review)
    tokenized_words = ' '.join(words)
    return tokenized_words
def remove_stopwords(text):
    stopwords = nltk.corpus.stopwords.words('english')
    tokens = word_tokenize(text)
    cleaned = [word for word in tokens if word not in stopwords]
    return ' '.join(cleaned)
def postag_lemmentization(text):
    lemmatizer = WordNetLemmatizer()
    tokens = word_tokenize(text)
    lemmatized_output_with_POS_information = [
        lemmatizer.lemmatize(word, get_part_of_speech_tags(word)) for word in tokens  ]
    return  ' '.join(lemmatized_output_with_POS_information)
def get_part_of_speech_tags(token):
    
    tag_dict = {"J": wordnet.ADJ,
                "N": wordnet.NOUN,
                "V": wordnet.VERB,
                "R": wordnet.ADV}
    
    tag = nltk.pos_tag([token])[0][1][0].upper()
    return tag_dict.get(tag, wordnet.NOUN)
def preprocess_text(text):
    soup = remove_html(text)
    tokenized_text = tokenizer_explodes(soup)
    tokenized_and_remove_stopwords = remove_stopwords(tokenized_text)
    preprocessed_text = postag_lemmentization(tokenized_and_remove_stopwords)
    return preprocessed_text

##APP Support - S3 and Database upload
def conversation_explode():
    transcribed_text = session.get('transcribed_text')
    if not transcribed_text:
        return

    preprocessed_string = preprocess_text(transcribed_text)
    words = preprocessed_string.split()  # Adjust `explode` as necessary
    conversation_id = Conversation.query.filter_by(user_id=session['user_id']).first().id

    for word in words:
        detail = Conversation_Detail(conversation_id=conversation_id, word=word)
        db.session.add(detail)

    db.session.commit()

def s3_upload():
    file_path = session.get('file_path')
    conversation = Conversation.query.filter_by(user_id=session['user_id']).first()
    if not conversation:
        return

    s3_file_path = f"{conversation.user_id}_{conversation.id}"
    try:
        s3_client.upload_file(file_path, S3_BUCKET, s3_file_path)
    except Exception as e:
        print(f"Failed to upload to S3: {str(e)}")
        return

    # Generate S3 file URL
    s3_url = f"https://{S3_BUCKET}.s3.{S3_REGION}.amazonaws.com/{s3_file_path}"
    conversation.s3_url = s3_url
    db.session.commit()
    os.remove(file_path)

    

#===================-------------Database Functions-------------===================#
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Conversation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True,default="Unknown User")
    transcription = db.Column(db.Text, nullable=False, default="No transcription available")
    csat_scores = db.Column(db.Float, nullable=True)
    qualative_evaluation = db.Column(db.Text, nullable=True)
    emotion_angry = db.Column(db.Float, nullable=True)
    emotion_fear = db.Column(db.Float, nullable=True)
    emotion_happy = db.Column(db.Float, nullable=True)
    emotion_sad = db.Column(db.Float, nullable=True)
    emotion_disgust = db.Column(db.Float, nullable=True)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship('User', backref=db.backref('conversations', lazy=True))
class Conversation_Detail(db.Model):
    id = db.Column(db.Integer, primary_key=True)  # Primary key for the model
    conversation_id = db.Column(db.Integer, db.ForeignKey('conversation.id'), nullable=False)
    word = db.Column(db.Text, nullable=True)
    conversation = db.relationship('Conversation', backref=db.backref('details', lazy=True))  # Define the relationship



#===================-------------APP ROUTING-------------===================#
@app.route('/')
def index():
    # # Fetch the HTML content from S3
    # s3_url = 'https://etliens1.s3.us-east-1.amazonaws.com/index.html'
    # response = requests.get(s3_url)

    # if response.status_code == 200:
    #     # Serve the fetched HTML content
    #     return Response(response.text, mimetype='text/html')
    # else:
    #     return "Error fetching page", response.status_code


    is_logged_in = session.get('logged_in', False)
    return render_template('index.html',isLoggedIn=is_logged_in)


@app.route('/register', methods=['POST', 'GET'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']

        # Check if email already exists
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash("Email already exists. Please sign in.", "error")
            return redirect(url_for('login'))  # Redirect to login page

        # Hash the password using bcrypt
        hashed_pw = bcrypt.generate_password_hash(password).decode('utf-8')

        # Create and add the new user
        user = User(name=name, email=email, password=hashed_pw)
        db.session.add(user)

        try:
            db.session.commit()
            flash("Successfully registered! Please sign in.", "success")
            return redirect(url_for('login'))
        except IntegrityError:
            db.session.rollback()
            flash("An error occurred. Please try again later.", "error")
            return redirect(url_for('register'))

    return render_template('register.html')

@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        data = request.form
        user = User.query.filter_by(email=data['email']).first()

        if user and bcrypt.check_password_hash(user.password, data['password']):
            session['user_id'] = user.id  # Store user id in session
            session['user_name'] = user.name  # Store user name in session
            flash("Login successful!", "success")
            session['logged_in'] = True
            return redirect(url_for('index'))  # Redirect to the index page after login
        
        flash("Invalid credentials", "error")
        return redirect(url_for('login'))  # Redirect back to login if credentials are invalid

    return render_template('login.html')

@app.route('/logout', methods=['POST'])
def logout():
    session.pop('logged_in', None)  # Clear the session data
    return redirect(url_for('index'))
@app.route('/primaryModel_output', methods=['POST', 'GET'])
def upload():
    # Save and process the uploaded audio file
    file_path = save_file_path(request)
    transcribed_text = transcribe_audio(file_path)

    if not transcribed_text:
        return jsonify({'error': 'Could not transcribe audio.'}), 500

    # Generate feedback and CSAT score
    input_ids = tokenizer(transcribed_text, return_tensors="pt").input_ids
    outputs = eval_model.generate(input_ids, max_length=150, num_beams=4, early_stopping=True)
    model_feedback_text = tokenizer.decode(outputs[0], skip_special_tokens=True)

    inputs = tokenizer_csat(transcribed_text, padding=True, truncation=True, max_length=512, return_tensors='pt')
    with torch.no_grad():
        outputs = csat_model(**inputs)
        raw_score = outputs.logits.squeeze(-1).item()
    csat_score = scale_score_to_1_10(raw_score)

    # Save to database
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'error': 'User not logged in.'}), 401

    # Create a new conversation record
    conversation = Conversation(
        user_id=user_id,
        transcription=transcribed_text,
        csat_scores=csat_score,
        qualative_evaluation=model_feedback_text
    )
    db.session.add(conversation)
    db.session.commit()

    # Save the file path in the session for further processing if needed
    session['file_path'] = file_path
    session['transcribed_text'] = transcribed_text

    # Upload to S3
    s3_upload()

    # Preprocess and explode conversation details
    conversation_explode()

    return jsonify({'model_feedback_text': model_feedback_text, 'csat_score': csat_score})


@app.route('/secondaryModel_output', methods=['POST'])
def upload2():
    # Retrieve the file path from the session
    file_path = session.get('file_path')
    
    if not file_path:
        return jsonify({'error': 'No file path found. Please upload a file first.'}), 400

    try:
        # Run the emotion prediction
        emotion_outputs = predict(file_path, sampling_rate)
    except Exception as e:
        return jsonify({'error': f"Prediction failed: {str(e)}"}), 500
        # Process results
    results = {}
    for output in emotion_outputs:
        if isinstance(output, dict):
            emotion = output.get('Emotion')
            score = output.get('Score')
            if emotion and score is not None:
                results[emotion] = score
    # Process the outputs into a structured format
    emotions = {output['Emotion']: float(output['Score'].strip('%')) / 100 for output in emotion_outputs}

    # Retrieve the current conversation record
    user_id = session.get('user_id')
    conversation = Conversation.query.filter_by(user_id=user_id).order_by(Conversation.timestamp.desc()).first()

    if not conversation:
        return jsonify({'error': 'No conversation found for the user.'}), 404

    # Update the conversation record with emotion scores
    conversation.emotion_angry = emotions.get('anger', 0.0)
    conversation.emotion_fear = emotions.get('fear', 0.0)
    conversation.emotion_happy = emotions.get('happiness', 0.0)
    conversation.emotion_sad = emotions.get('sadness', 0.0)
    conversation.emotion_disgust = emotions.get('disgust', 0.0)

    # Commit the updates to the database
    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': f"Database update failed: {str(e)}"}), 500


    # Return the results
    return jsonify(results)

