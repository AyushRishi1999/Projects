from app import app, db
import nltk
if __name__ == "__main__":
    with app.app_context():
        db.create_all()  # Creates tables only if they do not exist
        print("Tables created if they didn't already exist.")
    app.run(host="0.0.0.0", port=8000,   debug=True)
