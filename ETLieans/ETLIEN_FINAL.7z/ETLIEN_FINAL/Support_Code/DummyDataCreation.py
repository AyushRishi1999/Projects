import random
import mysql.connector
from datetime import datetime, timedelta

# Connect to your database
connection = mysql.connector.connect(
    host="etliens.c50y4qys259e.us-east-1.rds.amazonaws.com",
    user="admin",
    password="AWSRobby123",
    database='etliens'
)

cursor = connection.cursor()
cursor.execute("SELECT * FROM conversation")
existing_data = cursor.fetchall()

# Extract the number of existing records
total_existing_records = len(existing_data)

# Define the date range for randomization
today = datetime.now()
two_months_ago = today - timedelta(days=60)

# Number of records to generate
target_records = 1000
generated_count = 0

# Create the new table if not exists
cursor.execute("""
    CREATE TABLE IF NOT EXISTS conversation__expanded (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        transcription TEXT,
        csat_scores FLOAT,
        qualative_evaluation TEXT,
        emotion_angry FLOAT,
        emotion_fear FLOAT,
        emotion_happy FLOAT,
        emotion_sad FLOAT,
        emotion_disgust FLOAT,
        timestamp DATETIME
    )
""")

# Generate records
while generated_count < target_records:
    for i, record in enumerate(existing_data):
        if generated_count >= target_records:
            break

        # Extract original values
        id_, user_id, transcription, csat_scores, qual_eval, emotion_angry, emotion_fear, emotion_happy, emotion_sad, emotion_disgust, timestamp = record

        # Cycle the user ID
        user_id = (user_id % 4) + 1  # Assuming 4 users

        # Randomize the date
        random_days_delta = random.randint(0, 60)
        randomized_date = today - timedelta(days=random_days_delta)

        # Randomize the hour within the 9 AM to 5 PM range
        random_hour = random.randint(9, 17)
        random_minute = random.randint(0, 59)
        random_second = random.randint(0, 59)
        randomized_timestamp = randomized_date.replace(
            hour=random_hour, minute=random_minute, second=random_second
        )

        # Scale scores slightly (0.95 to 1.05)
        random_scale = random.uniform(0.95, 1.05)
        new_csat_scores = csat_scores * random_scale
        new_emotion_angry = emotion_angry * random_scale
        new_emotion_fear = emotion_fear * random_scale
        new_emotion_happy = emotion_happy * random_scale
        new_emotion_sad = emotion_sad * random_scale
        new_emotion_disgust = emotion_disgust * random_scale

        # Insert into the new table
        insert_query = """
            INSERT INTO conversation__expanded 
            (user_id, transcription, csat_scores, qualative_evaluation, 
             emotion_angry, emotion_fear, emotion_happy, emotion_sad, emotion_disgust, timestamp) 
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        new_record = (
            user_id, transcription, new_csat_scores, qual_eval,
            new_emotion_angry, new_emotion_fear, new_emotion_happy,
            new_emotion_sad, new_emotion_disgust, randomized_timestamp.strftime('%Y-%m-%d %H:%M:%S')
        )
        cursor.execute(insert_query, new_record)
        generated_count += 1

# Commit changes
connection.commit()

# Close the connection
cursor.close()
connection.close()

print(f"Generated {generated_count} records in conversation__expanded!")