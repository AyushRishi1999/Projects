import mysql.connector

conn = mysql.connector.connect(
    host="etliens.c50y4qys259e.us-east-1.rds.amazonaws.com",
    user="admin",
    password="AWSRobby123"
)

cursor = conn.cursor()
cursor.execute("CREATE DATABASE etliens;")
conn.commit()

conn.close()

